package t4a1;

import java.util.Scanner;

public class T4A1 {

    
    
    public static void main(String[] args) {
       //Ejercicio1(); 
       //Ejercicio2();
       //Ejercicio3();
       Ejercicio4();
    }
    
    // Escribir un programa que solicite un n�mero positivo y nos muestre desde
    // hasta el valor ingresado de uno en uno. Ejemplo: Si ingresamos 30 se debe
    // mostrar en pantalla los n�meros del 1 al 30.
    
    public static void Ejercicio1(){
    
        Scanner scanner = new Scanner(System.in); 
        
        int numero = 0;
    
        System.out.println("Hasta donde quieres llegar: ");
        int limite = scanner.nextInt();
    
        while(numero < limite){
        numero++;
        System.out.println(numero);
    
    }

}
    
    // Una maquiladora confecciona pantalones y recibe un lote de N piezas para
    // un cliente X. Crear un programa en Java que solicite la cantidad de piezas
    // a confeccionar y luego se ingrese las respectivas tallas que pueden ser S,
    // M, L y XL. Luego, imprimir en pantalla la cantidad de piezas confeccionadas
    // por talla.
    
    public static void Ejercicio2(){
        Scanner scanner = new Scanner(System.in); 
        
        System.out.println("Piezas a confeccionar ");
        int npiezas = scanner.nextInt();
        int n = 0, tallaS = 0, tallaM = 0, tallaL = 0, tallaXL = 0; 
        
        while(n < npiezas){
            n++;
            
            System.out.println("\nTalla: ");
            String talla = scanner.next();
            
            if(talla.equals("S") || talla.equals("s")){
                tallaS++;
            } else if (talla.equals("M") || talla.equals("m")){
                tallaM++;
            } else if (talla.equals("L")|| talla.equals("l")){
                tallaL++;
            } else {
                tallaXL++;
            }
            
            }
        System.out.println("Cantidades por talla: \n "
                + "Chica (S)\t\t" +tallaS + "\n"
                + "Mediana (M)\t\t" + tallaM + "\n"
                + "Grande (L)\t\t" + tallaL + "\n"
                + "Extragrande (XL)\t" + tallaXL);
    }
    
     // Escribir un programa en Java que solicite N calificaciones de estudiantes 
     // en una escala del 0 al 100 y que informe cu�ntos tienen calificaci�n mayor
     // o igual a 70 y cu�ntos tienen una calificaci�n menor. 
    
    public static void Ejercicio3(){
        Scanner scanner = new Scanner(System.in); 
        
        System.out.println("Ingresar calificaci�n: ");
        int calificacion = scanner.nextInt(); 
        int n = 0;
        
        while (n < calificacion){
            n++;
        if ( calificacion >= 70){
        System.out.println("Aprobado");
        }if(calificacion < 70) {
        System.out.println("No aprobado");
        }
           
            }
        }
    
    // Escribir un programa en Java que imprima los m�ltiplos del n�mero que 
    // indique el usuario hasta la cantidad deseada. El usuario debe indicar 
    // el m�ltiplo y el n�mero hasta el cual quiere llegar.
    public static void Ejercicio4(){
        Scanner scanner = new Scanner(System.in);
       
        System.out.println("Ingresar multiplo: ");
        System.out.println("Hasta donde quiere llegar: ");
        
        int multiplo = scanner.nextInt();
        int m = 0;
        int numero = scanner.nextInt();
        int n = 0;
        
        while(m <= numero){
            m ++;
            System.out.println( (m+m)  );
        }
        System.out.println("Resultado: "+ m);
    }
    }

